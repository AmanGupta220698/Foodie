package com.aman.androidfoodie.Interface;

import android.view.View;

/**
 * Created by Aman on 4/25/2019.
 */

public interface ItemClickListener {
    void onClick(View view,int position,boolean isLongClick);
}
