package com.aman.androidfoodie.Common;

import com.aman.androidfoodie.Model.User;

/**
 * Created by Aman on 4/25/2019.
 */

public class Common {
    public static User currentUser;
}
